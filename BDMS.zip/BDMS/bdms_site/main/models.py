from django.db import models
from django.utils import timezone
from django.conf import settings


# models --> tables

class Donor(models.Model):

    donor_id = models.SlugField(max_length=50,primary_key=True)
    donor_fname = models.CharField(max_length=50,null=True)
    donor_lname = models.CharField(max_length=50)
    donor_email = models.EmailField(max_length=254)
    donor_dob = models.SlugField(max_length=50)
    donor_address = models.TextField()
    donor_age = models.CharField(max_length=3)
    donor_phno = models.CharField(max_length=22)
    donor_gender = models.CharField(max_length=6)
    donor_bloodtype = models.CharField(max_length=10)
    organizations = models.ManyToManyField("BDO",related_name="Donors")
    donor_username = models.SlugField(max_length=100)

    def __str__(self):
        return self.donor_lname

    class Meta:
        db_table = "Donor"

class BDO(models.Model):
    bdo_oid = models.CharField(max_length=10, primary_key=True)
    bdo_name = models.CharField(max_length=225)
    bdo_address = models.TextField()
    bdo_optime = models.TextField()
    bdo_phno = models.CharField(max_length=22)
    inventory = models.ForeignKey('Inv',on_delete=models.SET_DEFAULT, default = 1)
    bdo_location = models.CharField(max_length=100,default =1 )

    def __str__(self):
        return self.bdo_name

    class Meta:
        db_table = "BDO"



class BDO_Staff(models.Model):
    bdo_staffid = models.CharField(max_length=50,primary_key=True)
    bdo_staff_fname = models.CharField(max_length=50)
    bdo_staff_lname = models.CharField(max_length=50)
    bdo_staff_formid = models.SlugField(max_length=50)
    bdorg =  models.ForeignKey('BDO',on_delete=models.SET_DEFAULT, default=1)
    bdo_staff_usname = models.SlugField(max_length=100,default=1)

    def __str__(self):
        return self.bdo_staff_lname

    class Meta:
        db_table = "BDO_Staff"



class BDE(models.Model):
    bde_id = models.CharField(max_length=50,primary_key=True)
    bde_location = models.CharField(max_length=50)
    bde_date = models.SlugField()
    bde_address = models.TextField()
    bde_time = models.SlugField()
    bde_desc = models.TextField()
    organizations = models.ManyToManyField("BDO",related_name="BDEs")
    def __str__(self):
        return self.bde_id

    class Meta:
        db_table = "BDE"

class Inv(models.Model):
    inv_id = models.CharField(max_length=50, primary_key=True)
    inv_qt = models.CharField(max_length=50)
    inv_bbd = models.SlugField()
    inv_bg = models.CharField(max_length=50)
    shipment_dets = models.ManyToManyField("Shp",related_name="Invs")

    def __str__(self):
        return self.inv_id

    class Meta:
        db_table = "Inv"

class Shp(models.Model):
    shp_id = models.CharField(max_length=50,primary_key=True)
    shp_mg = models.CharField(max_length=50)
    shp_ts = models.SlugField()
    shp_td = models.SlugField()
    bde_num = models.ForeignKey(BDE, on_delete=models.SET_DEFAULT, default=1)
    bdo_num = models.ForeignKey(BDO, on_delete=models.SET_DEFAULT,default=1)
    shipment_detail = models.ManyToManyField("HF",related_name="Shps")

    def __str__(self):
        return self.shp_id

    class Meta:
        db_table = "Shp"


class Req(models.Model):
    req_id = models.CharField(max_length=50,primary_key=True)
    req_dt = models.SlugField()
    req_bg = models.CharField(max_length=20)
    req_pri = models.CharField(max_length=25)
    req_loc = models.TextField()
    req_qt = models.CharField(max_length=10)
    reveices = models.ManyToManyField("BDO",related_name="Reqs")
    sendouts = models.ManyToManyField("HF",related_name="Reqs")

    def __str__(self):
        return self.req_id

    class Meta:
        db_table = "Req"


class HF_Staff(models.Model):
    hf_staff_id = models.CharField(max_length=50,primary_key=True)
    hf_staff_fname = models.CharField(max_length=50)
    hf_staff_lname = models.CharField(max_length=50)
    hfac = models.ForeignKey("HF",on_delete=models.SET_DEFAULT, default=1)
    hf_user = models.SlugField(max_length=100,default='1')

    def __str__(self):
        return self.hf_staff_lname

    class Meta:
        db_table = "HF_Staff"


class HF(models.Model):
    hf_id = models.CharField(max_length=10, primary_key=True)
    hf_name = models.CharField(max_length=225)
    hf_address = models.TextField()
    hf_phno = models.CharField(max_length=50)
    hf_location = models.CharField(max_length=50,default=1)

    def __str__(self):
        return self.hf_name

    class Meta:
        db_table = "HF"


class Recp(models.Model):
    recp_id = models.CharField(max_length=10,primary_key=True)
    recp_fname = models.CharField(max_length=50)
    recp_lname = models.CharField(max_length=50)
    recp_phno = models.SlugField(max_length=30)
    recp_bloodtype = models.CharField(max_length=20)
    hfacility = models.ForeignKey(HF,on_delete=models.SET_DEFAULT, default=1)
    hfstaff_num = models.ForeignKey(HF_Staff,on_delete=models.SET_DEFAULT, default=1)

    def __str__(self):
        return self.recp_lname

    class Meta:
        db_table = "Recp"
