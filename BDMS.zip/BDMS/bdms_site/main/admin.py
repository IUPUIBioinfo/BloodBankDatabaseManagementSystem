from django.contrib import admin
from django.db import models
from .models import *

# Register your models here.


admin.site.register(Donor)
admin.site.register(BDO)
admin.site.register(BDO_Staff)
admin.site.register(BDE)
admin.site.register(Inv)
admin.site.register(Shp)
admin.site.register(Req)
admin.site.register(HF_Staff)
admin.site.register(HF)
admin.site.register(Recp)
