from django.shortcuts import render, redirect
from django.urls import reverse
from django.forms import ModelForm, formset_factory
from django.contrib.auth.forms import  AuthenticationForm
from django.contrib.auth import login, logout, authenticate, get_user_model
from django.contrib import messages
from .forms import *
from .models import *
from django.template import RequestContext
from django.http import HttpResponseRedirect

def redirect_with_params(viewname, **kwargs):
    """
    Redirect a view with params
    """
    rev = reverse(viewname)

    params = urllib.parse.urlencode(kwargs)
    if params:
        rev = '{}?{}'.format(rev, params)

    return HttpResponseRedirect(rev)

# Create your views here.
def mainDisplay(request):
    query = ""

    if request.GET:
        query = request.GET.get("q")
        request.session['search_term'] = query

        return redirect("/result_dash")

    return render(request,
                   "main/main1.html")

def login_page(request):
    return render(request,
                    "main/login.html")

def logout_request(request):
    logout(request)
    messages.info( request, f"Logged out successfully")
    return redirect("/main")


def register(request):
    return render(request,
                    "main/register.html")

def account(request):
    username = request.user.username
    ids_from_ses = request.session['typo']

    if (ids_from_ses == 'dnr'):
        return redirect("/donor_dash")

    elif (ids_from_ses == 'bds'):
        return redirect("/bd_dash")

    elif (ids_from_ses == 'hfs'):
        return redirect("/hf_dash")

    else:
        redirect("/main")


##########


def result_dash(request,query=None):

    location = request.session['search_term']


    if HF.objects.filter(hf_location = location).exists():

        location = request.session['search_term']

        return render(request,"dash/result_dash.html",
                            {'hf':HF.objects.filter(hf_location = location),'events': BDE.objects.filter(bde_location=location),'orgs':BDO.objects.filter(bdo_location=location)} )

    else:
        messages.info(request, f" No {location} found in database")

        return redirect("/main")

#########



def donor_dash(request):

    if request.method == "GET":
        username = request.user.username
        try:
            location = request.session['location']
        except:
            location =Donor.objects.filter(donor_username= username).values('donor_address')[0]['donor_address']

        return render(request,"dash/main_donor.html",
                        {'username':username,'events': BDE.objects.filter(bde_location=location),'orgs':BDO.objects.filter(bdo_location=location)})

def hf_dash(request):

    if request.method == "GET":
        username = request.user.username
        lname = HF_Staff.objects.filter(hf_user = username).values('hf_staff_lname')[0]['hf_staff_lname']
        try:
            hf_staff_num = request.session['hlt_id']
            hf_fac = request.session['hlt_fac']
        except:
            hf_staff_num = HF_Staff.objects.filter(hf_user = username).values('hf_staff_id')[0]['hf_staff_id']
            hf_fac = HF_Staff.objects.filter(hf_user = username).values('hfac')[0]['hfac']


        location = HF.objects.filter(hf_id = hf_fac).values('hf_location')[0]['hf_location']

        return render(request,"dash/main_hf.html",
                        {'username':lname,'requests': Req.objects.filter(sendouts = hf_fac),'orgs':BDO.objects.filter(bdo_location=location),'recepients':Recp.objects.filter(hfstaff_num = hf_staff_num)})

def bd_dash(request):

    if request.method == "GET":
        username = request.user.username

        org_num = BDO_Staff.objects.filter(bdo_staff_usname = username).values('bdorg')[0]['bdorg']
        location = BDO.objects.filter(bdo_oid = org_num).values('bdo_location')[0]['bdo_location']
        invs = BDO.objects.filter(bdo_oid = org_num).values('inventory')[0]['inventory']


        return render(request,"dash/main_bdo.html",
                        {'username':username,'donors': Donor.objects.filter(organizations = org_num ),
                        'invs': Inv.objects.filter(inv_id=invs),
                        'events':BDE.objects.filter(bde_location=location),
                        'shps':Shp.objects.filter(bdo_num = org_num)})


def register_donor_1(request):

    if request.method == "POST":
        form = NewUserForm(request.POST)

        if (form.is_valid()):
            user = form.save()
            username = form.cleaned_data.get("username")
            email = form.cleaned_data.get("email")
            messages.success(request, f"New donor account created: {username}")
            messages.info(request, f" Please fill in the required details for {username}")
            login(request,user)
            return redirect("/register_donor_2")
        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")

            return render(request = request,
                          template_name = "main/register_donor_1.html",
                          context={"form":form})
    else:

        form = NewUserForm()

    return render(request,
                  "main/register_donor_1.html",
                  context={"form":form})

def register_donor_2(request):

    if request.method == "POST":
        form = NewDonorForm(request.POST)

        if (form.is_valid()):
            donor = form.save()

            location = donor.donor_address
            username = request.user.username
            messages.info(request, f" You are now logged in and set up, {username}")
            request.session['location'] = location
            request.session['typo'] = 'dnr'

            return redirect("/donor_dash")

        else:
            return render(request,
                          "main/register_donor_2.html",
                          context={"form":form})

    else:

        form = NewDonorForm()

    return render(request,
                  "main/register_donor_2.html",
                  context={"form":form})

def register_hf_1(request):


    if request.method == "POST":
        form = NewUserForm(request.POST)

        if (form.is_valid()):
            user = form.save()

            username = form.cleaned_data.get("username")
            messages.success(request, f"New donor account created: {username}")
            login(request,user)
            messages.info(request, f" Please fill in the required details for {username}")
            return redirect("/register_hf_2")
        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")

            return render(request = request,
                          template_name = "main/register_hf_1.html",
                          context={"form":form})

    form = NewUserForm()
    return render(request,
                  "main/register_hf_1.html",
                  context={"form":form})

def register_hf_2(request):


    if request.method == "POST":
        form = NewHFForm(request.POST)

        if (form.is_valid()):
            user = form.save()

            username = request.user.username
            messages.info(request, f" You are now logged in and set up, {username}")
            request.session['typo'] = 'hfs'
            request.session['hlt_id'] = user.hf_staff_id
            request.session['hlt_fac'] = user.hfac

            return redirect("/hf_dash")
        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")

            return render(request = request,
                          template_name = "main/register_hf_2.html",
                          context={"form":form})

    form = NewHFForm()
    return render(request,
                  "main/register_hf_2.html",
                  context={"form":form})

def register_bds_1(request):

    if request.method == "POST":
        form = NewUserForm(request.POST)

        if (form.is_valid()):
            user = form.save()

            username = form.cleaned_data.get("username")
            messages.success(request, f"New donor account created: {username}")
            login(request,user)
            messages.info(request, f" You are now logged in as {username}")
            return redirect("/register_bds_2")
        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")

            return render(request = request,
                          template_name = "main/register_bds_1.html",
                          context={"form":form})

    form = NewUserForm()

    return render(request,
                  "main/register_bds_1.html",
                  context={"form":form})

def register_bds_2(request):

    if request.method == "POST":
        form = NewBDForm(request.POST)

        if (form.is_valid()):
            user = form.save()

            username = request.user.username
            messages.info(request, f" You are now logged in and set up, {username}")
            request.session['typo'] = 'bds'

            return redirect("/bd_dash")
        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")

            return render(request = request,
                          template_name = "main/register_bds_2.html",
                          context={"form":form})

    form = NewBDForm()

    return render(request,
                  "main/register_bds_2.html",
                  context={"form":form})




def login_donor(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data = request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username = username, password = password)
            request.session['typo'] = 'dnr'
            if user is not None:
                login(request, user)
                messages.info(request, f" You are now logged in as {username}")
                return redirect("/main")
            else:
                messages.error(request, f"Invalid Username or Password")
        else:
            messages.error(request, f"Invalid details reported")

    form = AuthenticationForm()
    return render(request,
                    "main/login_donor.html",
                     context={"form":form})



def login_hf(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data = request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username = username, password = password)
            request.session['typo'] = 'hfs'
            if user is not None:
                login(request, user)
                messages.info(request, f" You are now logged in as {username}")
                return redirect("/main")
            else:
                messages.error(request, f"Invalid Username or Password")
        else:
            messages.error(request, f"Invalid details reported")

    form = AuthenticationForm()
    return render(request,
                    "main/login_hf.html",
                     context={"form":form})



def login_bds(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data = request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username = username, password = password)
            request.session['typo'] = 'bds'
            if user is not None:
                login(request, user)
                messages.info(request, f" You are now logged in as {username}")
                return redirect("/main")
            else:
                messages.error(request, f"Invalid Username or Password")
        else:
            messages.error(request, f"Invalid details reported")

    form = AuthenticationForm()
    return render(request,
                    "main/login_bds.html",
                     context={"form":form})

def request_bld(request):
    if request.method == "POST":

        form = RequestForm(request.POST)

        if form.is_valid():
            request = form.save()

            return redirect("/hf_dash")

        else:
            messages.error(request, f"Invalid request placed")
    else:
        messages.error(request, f"Form details are not right")

    form = RequestForm()
    return render(request,
                    "main/req_form.html",
                     context={"form":form})
