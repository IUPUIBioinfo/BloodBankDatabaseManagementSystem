from django import forms
from django.db import models
from django.forms import ModelForm, formset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *

genders = [('M','Male'),('F','Female'),('Other','Other')]

class NewUserForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ("username","email","password1","password2")

    def save(self, commit=True):
        user = super(NewUserForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user


class NewDonorForm(ModelForm):

    class Meta:
        model = Donor
        fields = ('__all__')



class NewHFForm(ModelForm):

    class Meta:
        model = HF_Staff
        fields = ('__all__')


class NewBDForm(ModelForm):

    class Meta:
        model = BDO_Staff
        fields = ('__all__')

class RequestForm(ModelForm):

    class Meta:
        model = Req
        fields = ('__all__')

class SearchLocForm(ModelForm):
    search_location = forms.CharField(max_length=1000)
